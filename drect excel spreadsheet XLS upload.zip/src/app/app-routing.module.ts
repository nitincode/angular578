import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductListComponent } from './compenents/product-list/product-list.component';
import { CounterComponent } from './counter/counter/counter.component';

const routes: Routes = [
  {
    path:'abc',
    component: CounterComponent
},
{
  path:'prd',
  component: ProductListComponent
},
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
