import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent implements OnInit {
  counterParent:number=0;  
  selectedFile: File;
  storeData: string | ArrayBuffer;
  showButton: boolean;
    // these value we are passng to chld counter output
  // thesee example has :-- 2 chld wth 1 parent 
  constructor() { }

  ngOnInit(): void {

  }

  public onFileChanged(event) {    
    //this.selectedFile = event.target.files[0]
   
      let reader = new FileReader();
      if(event.target.files && event.target.files.length > 0) {
          this.showButton= true;
        this.selectedFile = event.target.files[0];
        reader.readAsDataURL(this.selectedFile);
        reader.onload = () => {
          this.storeData = reader.result; 
        
        }
       
      }


  }

  onSubmit(event) {
    // alert("anil");
    console.log(this.storeData);

 }
 

  incParentClick() {

 this.counterParent++;
  }

  decParentClick() {

 this.counterParent--;

  }

  resParentClick() {

 this.counterParent=0;
  }

}
