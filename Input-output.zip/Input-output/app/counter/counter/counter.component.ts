import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent implements OnInit {
  counterParent:number=0;  
    // these value we are passng to chld counter output
  // thesee example has :-- 2 chld wth 1 parent 
  constructor() { }

  ngOnInit(): void {

  }
  incParentClick() {

 this.counterParent++;



  }

  decParentClick() {

 this.counterParent--;

  }

  resParentClick() {

 this.counterParent=0;
  }

}
