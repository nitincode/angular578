import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-counter-buttons',
  templateUrl: './counter-buttons.component.html',
  styleUrls: ['./counter-buttons.component.css']
})
export class CounterButtonsComponent implements OnInit {

  constructor() { }

  @Output()  increment = new EventEmitter<string>();
  @Output() decrement = new EventEmitter<string>();
  @Output()  reset = new EventEmitter<string>();


  ngOnInit(): void {
  }

  incrementClick() {

      this.increment.emit();

   // jeva apan chld to parent data pathvto teva 
   //  output emt vrble ha parent chya method la bind krycha so parent method call hote  
  }

  decrementClick() {

    this.decrement.emit();


  }

  resetClick() {
  this.reset.emit();

  }

}
