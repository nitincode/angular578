import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './compenents/product-list/product-list.component';
import { CounterComponent } from './counter/counter/counter.component';
import { CounterButtonsComponent } from './counter-button/counter-buttons/counter-buttons.component';
import { CounterOutputsComponent } from './counter-output/counter-outputs/counter-outputs.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    CounterComponent,
    CounterButtonsComponent,
    CounterOutputsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
