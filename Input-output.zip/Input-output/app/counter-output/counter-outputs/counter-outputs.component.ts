import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter-outputs',
  templateUrl: './counter-outputs.component.html',
  styleUrls: ['./counter-outputs.component.css']
})
export class CounterOutputsComponent implements OnInit {
  @Input() counterChld = ''; // decorate the property with @Input()

  constructor() { }

  ngOnInit(): void {
  }

}
