import { Component, OnInit } from '@angular/core';
import { ProductListService } from './product-list.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  userName: string = "tektutorialshub"
 
  loading: boolean = false;
  errorMessage;
  repos: any[];

  constructor(private productListService:ProductListService) { }

  ngOnInit(): void {
  }

  // public getData() {
  //   this.loading = true;
  //   this.errorMessage = "";
  //   this.productListService.getRepoData()
  //     .subscribe(
  //       (response) => {                           //Next callback
  //         console.log('response received')
  //         this.repos = response;
  //       },
  //       (error) => {                              //Error callback
  //         console.error('error caught in component')
  //         this.errorMessage = "not data";
  //         this.loading = false;
    
  //       }
  //     )
  // }


}
