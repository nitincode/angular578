import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductListService {

 // baseURL: string = "https://jsonplaceholder.typicode.com/userss"

  constructor(private http: HttpClient) {
  }


  // getRepoData(): Observable<any[]> {
  //   return this.http.get<any[]>(this.baseURL)
  //     .pipe(
  //       catchError((err) => {
  //         console.log('error caught in service')
  //         console.error(err);
  //         return throwError(err);
  //       })
  //     )
 // }

}
